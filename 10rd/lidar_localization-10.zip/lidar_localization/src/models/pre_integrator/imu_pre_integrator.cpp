/*
 * @Description: IMU pre-integrator for LIO mapping, implementation
 * @Author: Ge Yao
 * @Date: 2020-11-29 15:47:49
 */

#include "lidar_localization/models/pre_integrator/imu_pre_integrator.hpp"

#include "lidar_localization/global_defination/global_defination.h"

#include "glog/logging.h"

namespace lidar_localization {

IMUPreIntegrator::IMUPreIntegrator(const YAML::Node& node) {
    //
    // parse config:
    // 
    // a. earth constants:
    EARTH.GRAVITY_MAGNITUDE = node["earth"]["gravity_magnitude"].as<double>();
    // b. process noise:
    COV.MEASUREMENT.ACCEL = node["covariance"]["measurement"]["accel"].as<double>();
    COV.MEASUREMENT.GYRO = node["covariance"]["measurement"]["gyro"].as<double>();
    COV.RANDOM_WALK.ACCEL = node["covariance"]["random_walk"]["accel"].as<double>();
    COV.RANDOM_WALK.GYRO = node["covariance"]["random_walk"]["gyro"].as<double>();    

    // prompt:
    LOG(INFO) << std::endl 
              << "IMU Pre-Integration params:" << std::endl
              << "\tgravity magnitude: " << EARTH.GRAVITY_MAGNITUDE << std::endl
              << std::endl
              << "\tprocess noise:" << std::endl
              << "\t\tmeasurement:" << std::endl
              << "\t\t\taccel.: " << COV.MEASUREMENT.ACCEL << std::endl
              << "\t\t\tgyro.: " << COV.MEASUREMENT.GYRO << std::endl
              << "\t\trandom_walk:" << std::endl
              << "\t\t\taccel.: " << COV.RANDOM_WALK.ACCEL << std::endl
              << "\t\t\tgyro.: " << COV.RANDOM_WALK.GYRO << std::endl
              << std::endl;

    // a. gravity constant:
    state.g_ = Eigen::Vector3d(
        0.0, 
        0.0, 
        EARTH.GRAVITY_MAGNITUDE
    );

    // b. process noise:
    Q_.block<3, 3>(INDEX_M_ACC_PREV, INDEX_M_ACC_PREV) = Q_.block<3, 3>(INDEX_M_ACC_CURR, INDEX_M_ACC_CURR) = COV.MEASUREMENT.ACCEL * Eigen::Matrix3d::Identity();
    Q_.block<3, 3>(INDEX_M_GYR_PREV, INDEX_M_GYR_PREV) = Q_.block<3, 3>(INDEX_M_GYR_CURR, INDEX_M_GYR_CURR) = COV.MEASUREMENT.GYRO * Eigen::Matrix3d::Identity();
    Q_.block<3, 3>(INDEX_R_ACC_PREV, INDEX_R_ACC_PREV) = COV.RANDOM_WALK.ACCEL * Eigen::Matrix3d::Identity();
    Q_.block<3, 3>(INDEX_R_GYR_PREV, INDEX_R_GYR_PREV) = COV.RANDOM_WALK.GYRO * Eigen::Matrix3d::Identity();

    // c. process equation, state propagation:
    F_.block<3, 3>(INDEX_ALPHA,  INDEX_BETA) =  Eigen::Matrix3d::Identity();
    F_.block<3, 3>(INDEX_THETA,   INDEX_B_G) = -Eigen::Matrix3d::Identity();

    // d. process equation, noise input:
    B_.block<3, 3>(INDEX_THETA, INDEX_M_GYR_PREV) = B_.block<3, 3>(INDEX_THETA, INDEX_M_GYR_CURR) = 0.50 * Eigen::Matrix3d::Identity();
    B_.block<3, 3>(INDEX_B_A, INDEX_R_ACC_PREV) = B_.block<3, 3>(INDEX_B_G, INDEX_R_GYR_PREV) = Eigen::Matrix3d::Identity();
}

/**
 * @brief  reset IMU pre-integrator
 * @param  init_imu_data, init IMU measurements
 * @return true if success false otherwise
 */
bool IMUPreIntegrator::Init(const IMUData &init_imu_data) {
    // reset pre-integrator state:
    ResetState(init_imu_data);
    
    // mark as inited:
    is_inited_ = true;

    return true;
}

/**
 * @brief  update IMU pre-integrator
 * @param  imu_data, current IMU measurements
 * @return true if success false otherwise
 */
bool IMUPreIntegrator::Update(const IMUData &imu_data) {
    if ( imu_data_buff_.front().time < imu_data.time ) {
        // set buffer:
        imu_data_buff_.push_back(imu_data);

        // update state mean, covariance and Jacobian:
        UpdateState();

        // move forward:
        imu_data_buff_.pop_front();
    }

    return true;
}

/**
 * @brief  reset IMU pre-integrator using new init IMU measurement
 * @param  init_imu_data, new init IMU measurements
 * @param  output pre-integration result for constraint building as IMUPreIntegration
 * @return true if success false otherwise
 */
bool IMUPreIntegrator::Reset(
    const IMUData &init_imu_data, 
    IMUPreIntegration &imu_pre_integration
) {
    // one last update:
    Update(init_imu_data);

    // set output IMU pre-integration:
    imu_pre_integration.T_ = init_imu_data.time - time_;

    // set gravity constant:
    imu_pre_integration.g_ = state.g_;

    // set measurement:
    imu_pre_integration.alpha_ij_ = state.alpha_ij_;
    imu_pre_integration.theta_ij_ = state.theta_ij_;
    imu_pre_integration.beta_ij_ = state.beta_ij_;
    imu_pre_integration.b_a_i_ = state.b_a_i_;
    imu_pre_integration.b_g_i_ = state.b_g_i_;
    // set information:
    imu_pre_integration.P_ = P_;
    // set Jacobian:
    imu_pre_integration.J_ = J_;

    // reset:
    ResetState(init_imu_data);

    return true;
}

/**
 * @brief  reset pre-integrator state using IMU measurements
 * @param  void
 * @return void
 */
void IMUPreIntegrator::ResetState(const IMUData &init_imu_data) {
    // reset time:
    time_ = init_imu_data.time;

    // a. reset relative translation:
    state.alpha_ij_ = Eigen::Vector3d::Zero();
    // b. reset relative orientation:
    state.theta_ij_ = Sophus::SO3d();
    // c. reset relative velocity:
    state.beta_ij_ = Eigen::Vector3d::Zero();
    // d. set init bias, acceleometer:
    state.b_a_i_ = Eigen::Vector3d(
        init_imu_data.accel_bias.x,
        init_imu_data.accel_bias.y,
        init_imu_data.accel_bias.z
    );
    // d. set init bias, gyroscope:
    state.b_g_i_ = Eigen::Vector3d(
        init_imu_data.gyro_bias.x,
        init_imu_data.gyro_bias.y,
        init_imu_data.gyro_bias.z
    );

    // reset state covariance:
    P_ = MatrixP::Zero();

    // reset Jacobian:
    J_ = MatrixJ::Identity();

    // reset buffer:
    imu_data_buff_.clear();
    imu_data_buff_.push_back(init_imu_data);
}

/**
 * @brief  update pre-integrator state: mean, covariance and Jacobian
 * @param  void
 * @return void
 */
void IMUPreIntegrator::UpdateState(void) {
    static double T = 0.0;

    static Eigen::Vector3d w_mid = Eigen::Vector3d::Zero();
    static Eigen::Vector3d a_mid = Eigen::Vector3d::Zero();

    static Sophus::SO3d prev_theta_ij = Sophus::SO3d();
    static Sophus::SO3d curr_theta_ij = Sophus::SO3d();
    static Sophus::SO3d d_theta_ij = Sophus::SO3d();

    static Eigen::Matrix3d dR_inv = Eigen::Matrix3d::Zero();
    static Eigen::Matrix3d prev_R = Eigen::Matrix3d::Zero();
    static Eigen::Matrix3d curr_R = Eigen::Matrix3d::Zero();
    static Eigen::Matrix3d prev_R_a_hat = Eigen::Matrix3d::Zero();
    static Eigen::Matrix3d curr_R_a_hat = Eigen::Matrix3d::Zero();

    //
    // parse measurements:
    //
    // get measurement handlers:
    const IMUData &prev_imu_data = imu_data_buff_.at(0);
    const IMUData &curr_imu_data = imu_data_buff_.at(1);

    // get time delta:
    T = curr_imu_data.time - prev_imu_data.time;

    // // get measurements:
    // const Eigen::Vector3d prev_w(
    //     prev_imu_data.angular_velocity.x - state.b_g_i_.x(),
    //     prev_imu_data.angular_velocity.y - state.b_g_i_.y(),
    //     prev_imu_data.angular_velocity.z - state.b_g_i_.z()
    // );
    // const Eigen::Vector3d curr_w(
    //     curr_imu_data.angular_velocity.x - state.b_g_i_.x(),
    //     curr_imu_data.angular_velocity.y - state.b_g_i_.y(),
    //     curr_imu_data.angular_velocity.z - state.b_g_i_.z()
    // );

    // const Eigen::Vector3d prev_a(
    //     prev_imu_data.linear_acceleration.x - state.b_a_i_.x(),
    //     prev_imu_data.linear_acceleration.y - state.b_a_i_.y(),
    //     prev_imu_data.linear_acceleration.z - state.b_a_i_.z()
    // );
    // const Eigen::Vector3d curr_a(
    //     curr_imu_data.linear_acceleration.x - state.b_a_i_.x(),
    //     curr_imu_data.linear_acceleration.y - state.b_a_i_.y(),
    //     curr_imu_data.linear_acceleration.z - state.b_a_i_.z()
    // );

    Eigen::Vector3d prev_w(prev_imu_data.angular_velocity.x, prev_imu_data.angular_velocity.y, prev_imu_data.angular_velocity.z);
    Eigen::Vector3d curr_w(curr_imu_data.angular_velocity.x, curr_imu_data.angular_velocity.y, curr_imu_data.angular_velocity.z);
    Eigen::Vector3d prev_a(prev_imu_data.linear_acceleration.x, prev_imu_data.linear_acceleration.y, prev_imu_data.linear_acceleration.z);
    Eigen::Vector3d curr_a(curr_imu_data.linear_acceleration.x, curr_imu_data.linear_acceleration.y, curr_imu_data.linear_acceleration.z);

    // check
    // Eigen::Vector3d turb(0.0001, -0.003, 0.003);
    Eigen::Vector3d turb(0.000001, -0.00003, 0.00003);
    Eigen::Vector3d curr_delta_p = Eigen::Vector3d::Zero();
    Sophus::SO3d curr_delta_q = Sophus::SO3d();
    Eigen::Vector3d curr_delta_v = Eigen::Vector3d::Zero();
    Eigen::Vector3d curr_ba = Eigen::Vector3d::Zero();
    Eigen::Vector3d curr_bg = Eigen::Vector3d::Zero();
    MatrixF step_J = MatrixF::Zero();
    MatrixB step_B = MatrixB::Zero();
    // a. 位置加扰动
    CheckJacobian(T, prev_a, prev_w, curr_a, curr_w, 
        state.alpha_ij_ + turb, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // b. 姿态加扰动
    Sophus::SO3d q_turb = state.theta_ij_ * Sophus::SO3d::exp(turb);
    CheckJacobian(T, prev_a, prev_w, curr_a, curr_w, 
        state.alpha_ij_, q_turb, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // c. 速度加扰动
    CheckJacobian(T, prev_a, prev_w, curr_a, curr_w, 
        state.alpha_ij_, state.theta_ij_, state.beta_ij_ + turb, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // d. ba加扰动
    CheckJacobian(T, prev_a, prev_w, curr_a, curr_w, 
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_ + turb, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // e. bg加扰动
    CheckJacobian(T, prev_a, prev_w, curr_a, curr_w, 
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_ + turb,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // f. acc_0 加扰动
    CheckJacobian(T, prev_a + turb, prev_w, curr_a, curr_w, 
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // g. gyr_0 加扰动
    CheckJacobian(T, prev_a , prev_w + turb, curr_a, curr_w, 
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // h. acc_1 加扰动
    CheckJacobian(T, prev_a , prev_w , curr_a + turb, curr_w, 
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // i. gyr_1 加扰动
    CheckJacobian(T, prev_a , prev_w , curr_a , curr_w + turb,  
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // check jcaobian
    CheckJacobian(T, prev_a , prev_w , curr_a , curr_w,  
        state.alpha_ij_, state.theta_ij_, state.beta_ij_, state.b_a_i_, state.b_g_i_,
        curr_delta_p, curr_delta_q, curr_delta_v, curr_ba, curr_bg, step_J, step_B);
    // std::cout<<"J: "<<std::endl<<step_J<<std::endl;
    

    // unbiased
    prev_w = prev_w - state.b_g_i_;
    curr_w = curr_w - state.b_g_i_;
    prev_a = prev_a - state.b_a_i_;
    curr_a = curr_a - state.b_a_i_;

    //
    // a. update mean:
    //
    // 1. get w_mid:
    w_mid = 0.5 * ( prev_w + curr_w );
    // 2. update relative orientation, so3:
    prev_theta_ij = state.theta_ij_;
    d_theta_ij = Sophus::SO3d::exp(w_mid * T);
    state.theta_ij_ = state.theta_ij_ * d_theta_ij;
    curr_theta_ij = state.theta_ij_;
    // 3. get a_mid:
    a_mid = 0.5 * ( prev_theta_ij * prev_a + curr_theta_ij * curr_a );
    // 4. update relative translation:
    state.alpha_ij_ += (state.beta_ij_ + 0.5 * a_mid * T) * T;
    // 5. update relative velocity:
    state.beta_ij_ += a_mid * T;

    // std::cout<<"check v: "<<curr_delta_v.transpose()<<std::endl;
    // std::cout<<"v: "<<state.beta_ij_.transpose()<<std::endl<<std::endl;

    //
    // b. update covariance:
    //
    // 1. intermediate results:
    dR_inv = d_theta_ij.inverse().matrix();
    prev_R = prev_theta_ij.matrix();
    curr_R = curr_theta_ij.matrix();
    prev_R_a_hat = prev_R * Sophus::SO3d::hat(prev_a);
    curr_R_a_hat = curr_R * Sophus::SO3d::hat(curr_a);

    //
    // 2. set up F:
    //
    // F12 & F32:
    F_.block<3, 3>(INDEX_ALPHA, INDEX_THETA) = F_.block<3, 3>(INDEX_BETA, INDEX_THETA) = -0.50 * (prev_R_a_hat + curr_R_a_hat * dR_inv);
    F_.block<3, 3>(INDEX_ALPHA, INDEX_THETA) = 0.50 * T * F_.block<3, 3>(INDEX_ALPHA, INDEX_THETA);
    // F14 & F34:
    F_.block<3, 3>(INDEX_ALPHA,   INDEX_B_A) = F_.block<3, 3>(INDEX_BETA,   INDEX_B_A) = -0.50 * (prev_R + curr_R);
    F_.block<3, 3>(INDEX_ALPHA,   INDEX_B_A) = 0.50 * T * F_.block<3, 3>(INDEX_ALPHA,   INDEX_B_A);
    // F15 & F35:
    F_.block<3, 3>(INDEX_ALPHA,   INDEX_B_G) = F_.block<3, 3>(INDEX_BETA,   INDEX_B_G) = +0.50 * T * curr_R_a_hat;
    F_.block<3, 3>(INDEX_ALPHA,   INDEX_B_G) = 0.50 * T * F_.block<3, 3>(INDEX_ALPHA,   INDEX_B_G);
    // F22:
    F_.block<3, 3>(INDEX_THETA, INDEX_THETA) = -Sophus::SO3d::hat(w_mid);

    //
    // 3. set up G:
    //
    // G11 & G31:
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_PREV) = B_.block<3, 3>(INDEX_BETA, INDEX_M_ACC_PREV) = +0.50 * prev_R;
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_PREV) = 0.50 * T * B_.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_PREV);
    // G12 & G32:
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_PREV) = B_.block<3, 3>(INDEX_BETA, INDEX_M_GYR_PREV) = -0.25 * T * curr_R_a_hat;
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_PREV) = 0.50 * T * B_.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_PREV);
    // G13 & G33:
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_CURR) = B_.block<3, 3>(INDEX_BETA, INDEX_M_ACC_CURR) = 0.5 * curr_R;
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_CURR) = 0.50 * T * B_.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_CURR);
    // G14 & G34:
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_CURR) = B_.block<3, 3>(INDEX_BETA, INDEX_M_GYR_CURR) = -0.25 * T * curr_R_a_hat;
    B_.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_CURR) = 0.50 * T * B_.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_CURR);

    // 4. update P_:
    MatrixF F = MatrixF::Identity() + T * F_;
    MatrixB B = T * B_;

    // std::cout<<"my jacoiban:"<<std::endl<<F<<std::endl<<std::endl;

    P_ = F*P_*F.transpose() + B*Q_*B.transpose();

    // 
    // c. update Jacobian:
    //
    J_ = F * J_;


    // check
    // // a. 位移扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_J.block<3,3>(0,0)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_J.block<3,3>(3,0)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_J.block<3,3>(6,0)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_J.block<3,3>(9,0)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_J.block<3,3>(12,0)*turb).transpose()<<std::endl<<std::endl;

    // // b. 姿态扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_J.block<3,3>(0,3)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_J.block<3,3>(3,3)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_J.block<3,3>(6,3)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_J.block<3,3>(9,3)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_J.block<3,3>(12,3)*turb).transpose()<<std::endl<<std::endl;

    // // c. 速度扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_J.block<3,3>(0,6)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_J.block<3,3>(3,6)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_J.block<3,3>(6,6)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_J.block<3,3>(9,6)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_J.block<3,3>(12,6)*turb).transpose()<<std::endl<<std::endl;

    // // b. ba扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_J.block<3,3>(0,9)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_J.block<3,3>(3,9)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_J.block<3,3>(6,9)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_J.block<3,3>(9,9)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_J.block<3,3>(12,9)*turb).transpose()<<std::endl<<std::endl;

    // // e. bg扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_J.block<3,3>(0,12)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_J.block<3,3>(3,12)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_J.block<3,3>(6,12)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_J.block<3,3>(9,12)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_J.block<3,3>(12,12)*turb).transpose()<<std::endl<<std::endl;

    // // f. acc_0 扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_B.block<3,3>(0,0)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_B.block<3,3>(3,0)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_B.block<3,3>(6,0)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_B.block<3,3>(9,0)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_B.block<3,3>(12,0)*turb).transpose()<<std::endl<<std::endl;

    // // g. gyr_0 扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_B.block<3,3>(0,3)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_B.block<3,3>(3,3)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_B.block<3,3>(6,3)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_B.block<3,3>(9,3)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_B.block<3,3>(12,3)*turb).transpose()<<std::endl<<std::endl;

    // // h. acc_1 扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_B.block<3,3>(0,6)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_B.block<3,3>(3,6)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_B.block<3,3>(6,6)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_B.block<3,3>(9,6)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_B.block<3,3>(12,6)*turb).transpose()<<std::endl<<std::endl;

    // // i. gyr_1 扰动
    // std::cout<<"p diff: "<<(curr_delta_p - state.alpha_ij_).transpose()<<std::endl;
    // std::cout<<"p jaco diff: "<<(step_B.block<3,3>(0,9)*turb).transpose()<<std::endl;
    // std::cout<<"q diff: "<<((state.theta_ij_.inverse() * curr_delta_q).log()).transpose()<<std::endl;
    // std::cout<<"q jaco diff: "<<(step_B.block<3,3>(3,9)*turb).transpose()<<std::endl;
    // std::cout<<"v diff: "<<(curr_delta_v - state.beta_ij_).transpose()<<std::endl;
    // std::cout<<"v jaco diff: "<<(step_B.block<3,3>(6,9)*turb).transpose()<<std::endl;
    // std::cout<<"ba diff: "<<(curr_ba - state.b_a_i_).transpose()<<std::endl;
    // std::cout<<"ba jaco diff: "<<(step_B.block<3,3>(9,9)*turb).transpose()<<std::endl;
    // std::cout<<"bg diff: "<<(curr_bg - state.b_g_i_).transpose()<<std::endl;
    // std::cout<<"bg jaco diff: "<<(step_B.block<3,3>(12,9)*turb).transpose()<<std::endl<<std::endl;
}

void IMUPreIntegrator::CheckJacobian(double T, Eigen::Vector3d prev_a, Eigen::Vector3d prev_w,
    Eigen::Vector3d curr_a, Eigen::Vector3d curr_w, 
    Eigen::Vector3d prev_delta_p, Sophus::SO3d prev_delta_q, Eigen::Vector3d prev_delta_v, 
    Eigen::Vector3d prev_ba, Eigen::Vector3d prev_bg,
    Eigen::Vector3d& curr_delta_p, Sophus::SO3d& curr_delta_q, Eigen::Vector3d& curr_delta_v,
    Eigen::Vector3d& curr_ba, Eigen::Vector3d& curr_bg,
    MatrixF& step_J, MatrixB& step_B){
    
    // unbiased
    prev_w = prev_w - prev_bg;
    curr_w = curr_w - prev_bg;
    prev_a = prev_a - prev_ba;
    curr_a = curr_a - prev_ba;

    curr_ba = prev_ba;
    curr_bg = prev_bg;

    Eigen::Matrix3d dR_inv = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d prev_R = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d curr_R = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d prev_R_a_hat = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d curr_R_a_hat = Eigen::Matrix3d::Zero();
    
    Eigen::Vector3d w_mid = 0.5 * ( prev_w + curr_w );
    Sophus::SO3d d_theta_ij = Sophus::SO3d::exp(w_mid * T);
    curr_delta_q = prev_delta_q * d_theta_ij;

    Eigen::Vector3d a_mid = 0.5 * ( prev_delta_q * prev_a + curr_delta_q * curr_a );
    curr_delta_p = prev_delta_p + (prev_delta_v + 0.5*a_mid*T) * T;
    curr_delta_v = prev_delta_v + a_mid*T;

    // std::cout<<"check prev_delta_v: "<<prev_delta_v.transpose()<<std::endl;

    dR_inv = d_theta_ij.inverse().matrix();
    prev_R = prev_delta_q.matrix();
    curr_R = curr_delta_q.matrix();
    prev_R_a_hat = prev_R * Sophus::SO3d::hat(prev_a);
    curr_R_a_hat = curr_R * Sophus::SO3d::hat(curr_a);
    
    MatrixF F = MatrixF::Zero();
    MatrixB B = MatrixB::Zero();
    //
    // 2. set up F:
    //
    // // F12 & F32:
    // F.block<3, 3>(INDEX_ALPHA, INDEX_THETA) = F.block<3, 3>(INDEX_BETA, INDEX_THETA) = -0.50 * (prev_R_a_hat + curr_R_a_hat * dR_inv);
    // F.block<3, 3>(INDEX_ALPHA, INDEX_THETA) = 0.50 * T * F.block<3, 3>(INDEX_ALPHA, INDEX_THETA);
    // // F14 & F34:
    // F.block<3, 3>(INDEX_ALPHA,   INDEX_B_A) = F.block<3, 3>(INDEX_BETA,   INDEX_B_A) = -0.50 * (prev_R + curr_R);
    // F.block<3, 3>(INDEX_ALPHA,   INDEX_B_A) = 0.50 * T * F.block<3, 3>(INDEX_ALPHA,   INDEX_B_A);
    // // F15 & F35:
    // F.block<3, 3>(INDEX_ALPHA,   INDEX_B_G) = F.block<3, 3>(INDEX_BETA,   INDEX_B_G) = +0.50 * T * curr_R_a_hat;
    // F.block<3, 3>(INDEX_ALPHA,   INDEX_B_G) = 0.50 * T * F.block<3, 3>(INDEX_ALPHA,   INDEX_B_G);
    // // F22:
    // F.block<3, 3>(INDEX_THETA, INDEX_THETA) = -Sophus::SO3d::hat(w_mid);

    // F12 & F32:
    // F32:
    F.block<3,3>(INDEX_BETA,INDEX_THETA) = -0.5*(prev_R_a_hat+curr_R_a_hat*dR_inv);
    // F12:
    F.block<3,3>(INDEX_ALPHA,INDEX_THETA) = 0.5*T*F.block<3,3>(INDEX_BETA,INDEX_THETA);

    // F14 & F34:
    // F34:
    F.block<3,3>(INDEX_BETA,INDEX_B_A) = -0.5*(prev_R+curr_R);
    // F14:
    F.block<3,3>(INDEX_ALPHA,INDEX_B_A) = 0.5*T*F.block<3,3>(INDEX_BETA,INDEX_B_A);

    // F15 & F35:
    F.block<3,3>(INDEX_BETA,INDEX_B_G) = 0.5*T*curr_R_a_hat;
    F.block<3,3>(INDEX_ALPHA,INDEX_B_G) = 0.5*T*F.block<3,3>(INDEX_BETA,INDEX_B_G);

    // F22: 前面不用加单位阵 之后 F_=I+F_*T
    F.block<3,3>(INDEX_THETA,INDEX_THETA) = -Sophus::SO3d::hat(w_mid);

    F.block<3, 3>(INDEX_ALPHA,  INDEX_BETA) =  Eigen::Matrix3d::Identity();
    F.block<3, 3>(INDEX_THETA,   INDEX_B_G) = -Eigen::Matrix3d::Identity();

    //
    // 3. set up G:
    //
    // G11 & G31:
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_PREV) = B.block<3, 3>(INDEX_BETA, INDEX_M_ACC_PREV) = +0.50 * prev_R;
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_PREV) = 0.50 * T * B.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_PREV);
    // // G12 & G32:
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_PREV) = B.block<3, 3>(INDEX_BETA, INDEX_M_GYR_PREV) = -0.25 * T * curr_R_a_hat;
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_PREV) = 0.50 * T * B.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_PREV);
    // // G13 & G33:
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_CURR) = B.block<3, 3>(INDEX_BETA, INDEX_M_ACC_CURR) = 0.5 * curr_R;
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_CURR) = 0.50 * T * B.block<3, 3>(INDEX_ALPHA, INDEX_M_ACC_CURR);
    // // G14 & G34:
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_CURR) = B.block<3, 3>(INDEX_BETA, INDEX_M_GYR_CURR) = -0.25 * T * curr_R_a_hat;
    // B.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_CURR) = 0.50 * T * B.block<3, 3>(INDEX_ALPHA, INDEX_M_GYR_CURR);

    B.block<3,3>(INDEX_BETA,INDEX_M_ACC_PREV) = 0.5*prev_R;
    // G11
    B.block<3,3>(INDEX_ALPHA,INDEX_M_ACC_PREV) = 0.5*T*B.block<3,3>(INDEX_BETA,INDEX_M_ACC_PREV);

    // G12 & G32:
    // G32
    B.block<3,3>(INDEX_BETA,INDEX_M_GYR_PREV) = -0.25*T*curr_R_a_hat;
    // G12
    B.block<3,3>(INDEX_ALPHA,INDEX_M_GYR_PREV)  = 0.5*T*B.block<3,3>(INDEX_BETA,INDEX_M_GYR_PREV);

    // G13 & G33:
    // G33
    B.block<3,3>(INDEX_BETA,INDEX_M_ACC_CURR) = 0.5*curr_R;
    // G13
    B.block<3,3>(INDEX_ALPHA,INDEX_M_ACC_CURR) = 0.5*T*B.block<3,3>(INDEX_BETA,INDEX_M_ACC_CURR);

    // G14 & G34:
    B.block<3,3>(INDEX_BETA,INDEX_M_GYR_CURR) = -0.25*T*curr_R_a_hat;
    B.block<3,3>(INDEX_ALPHA,INDEX_M_GYR_CURR) = 0.5*T*B.block<3,3>(INDEX_BETA,INDEX_M_GYR_CURR);

    B.block<3, 3>(INDEX_THETA, INDEX_M_GYR_PREV) = B.block<3, 3>(INDEX_THETA, INDEX_M_GYR_CURR) = 0.50 * Eigen::Matrix3d::Identity();
    B.block<3, 3>(INDEX_B_A, INDEX_R_ACC_PREV) = B.block<3, 3>(INDEX_B_G, INDEX_R_GYR_PREV) = Eigen::Matrix3d::Identity();
    
    F = MatrixF::Identity() + T * F;
    B = T * B;

    step_J = F;
    step_B = B;
}

} // namespace lidar_localization